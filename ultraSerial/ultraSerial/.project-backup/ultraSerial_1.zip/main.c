#include <atmel_start.h>
#include <util/delay.h>
#include <hal_usart_sync.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	while (1) {
		/* Wait for data to be received */
		while (!usart_is_rx_ready(USART0)) {
		}

		/* Retrieve data */
		uint8_t data = usart_getchar(USART0);

		/* Echo back the data */
		usart_putchar(USART0, data);
	}
}

