#include <atmel_start.h>
#include <hal_delay.h>
#include <hal_usart_async.h>
#include "utils.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
		usart_sync_set_baud_rate(USART0,38400);
				struct io_descriptor *io;
					usart_sync_get_io_descriptor(&USART_0, &io);
		usart_sync_enable(&USART_0);

	while (1) {
	///* Wait for data to be received */
		//while (!usart_is_rx_ready(USART0)) {
			//
		//}
//
		///* Retrieve data */
		//uint8_t data = usart_getchar(USART0);
//
		///* Echo back the data */
		//usart_putchar(USART0, data);
		


		io_write(io, (uint8_t *)"Hello World!", 12);
	}
}

